<?php
// include database connection file
include "db.php";

// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{   
    $kode = $_POST['kode'];

    $nama =$_POST['nama'];
    $harga =$_POST['harga'];
    $jml_stok =$_POST['jml_stok'];

    // update user data
    $result = mysqli_query($konek, "UPDATE barang SET nama='$nama',harga='$harga_',jml_stok='$jjml_stok' WHERE kode_barang=$kode");

    // Redirect to homepage to display updated user in list
    header("Location: index.php");
}
?>
<?php
// Display selected user data based on kode
// Getting kode from url
$kode = $_GET['kode'];

// Fetech user data based on kode
$result = mysqli_query($conn, "SELECT * FROM barang WHERE kode_barang=$kode");

while($r = mysqli_fetch_array($result))
{
    $nama = $r['nama'];
    $harga = $r['harga_'];
    $jml_stok = $r['jml_stok'];
}
?>

<html>
<head>
 <title>Aplikasi Barang </title>
</head>
<body style="font-family:arial">
 <center><h2>Aplikasi Barang <br /> </h2></center>
 <hr />
 <b>Edit Data Barang</b>
    <br/><br/>
    <form name="update_user" method="post" action="edit.php">
        <table border="0">
            <tr> 
                <td>Nama Barang</td>
                <td><input type="text" size="50" name="nama" value="<?php echo $nama;?>"></td>
            </tr>
            <tr> 
                <td>Harga Barang</td>
                <td><input type="text" size="50" name="harga" value="<?php echo $harga;?>"></td>
            </tr>
            <tr> 
                <td>Stok Barang</td>
                <td><input type="text" size="50" name="jml_stok" value="<?php echo $jml_stok;?>"></td>
            </tr>
            <tr>
                <td><input type="hidden" name="kode" value=<?php echo $_GET['kode'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>