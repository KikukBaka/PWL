<?php

session_start();

require_once '../config/db.php';

// mencegah sql injection menggunakan fungsi mysql_real_escape_string()
$nama = mysql_real_escape_string($_POST['nama']);
$password = sha1(mysql_real_escape_string($_POST['password']));
$peran = $_POST['peran'];

if(empty($username) || empty($password) || empty($peran)) {
  header('Location: ../index.php');
}

$sql = "SELECT * FROM users WHERE nama = '" .$nama. "' AND password = '" .$password. "' AND peran = '" .$peran. "'";
$query = $conn->query($sql);
$result = $query->fetch_assoc();
var_dump($result);

if($query->num_rows > 0) {
  $_SESSION['name'] = $result['nama'];
  $_SESSION['kode_user'] = $result['kode_user'];

  if($result['id_level'] == 1) {
    header('Location: ../admin/index.php');
  } else {
    header('Location: ../operator/index.php');
  }
} else {
  $_SESSION['error'] = "Data yang anda masukan salah, silahkan coba lagi";
  header('Location: ../index.php');
}

?>
