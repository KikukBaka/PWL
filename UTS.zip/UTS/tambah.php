<html>
<head>
 <title>Aplikasi Barang | </title>
</head>
<body style="font-family:arial">
 <center><h2>Aplikasi Barang <br /> </h2></center>
 <hr />
 <b>Tambah Data Baru</b>
    <br/><br/>

    <form action="tambah.php" method="post" name="form1">
        <table width="100%" border="0">
            <tr> 
                <td>Nama Barang</td>
                <td><input type="text" name="nama" size="50" required></td>
            </tr>
            <tr> 
                <td>Harga Barang</td>
                <td><input type="text" name="harga" size="50" required></td>
            </tr>
            <tr> 
                <td>Stok Barang</td>
                <td><input type="text" name="jml_stok" size="50" required></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="+ Tambahkan"></td>
            </tr>
        </table>
    </form>

    <?php

    // Check If form submitted, insert form data into users table.
    if(isset($_POST['Submit'])) {
        $nama_barang = $_POST['nama'];
        $harga_barang = $_POST['harga'];
        $jml_stok = $_POST['jml_stok'];

        // include database connection file
        include "db.php";

        // Insert user data into table
  $tambah_barang = "insert into barang values('','$nama','$harga','$jml_stok')";
     $kerjakan=mysqli_query($conn, $tambah_barang);
     if($kerjakan)
     {
     // Show message when user added
     echo "Barang berhasil ditambahkan. <a href='index.php'>Lihat Data Barang</a>";
     }
     else
      {
      echo "Gabisa bro";
     }
    }
    ?>
</body>
</html>