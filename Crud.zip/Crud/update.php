<?php
$host = "localhost";
$user = "root";
$pass = "";
$database_name = "crud_pdo";
$pdo = new PDO("mysql:host=$host;dbname=$database_name", $user, $password, array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
));
try{
    $query = $pdo->prepare("update siswa set nama = :nama, alamat = :alamat, 
        logo = :logo where id = :id");
    $data = array(
        ':nama' => 'Budi Darsono',
        ':alamat' => 'Jl. Manggis No 4, Mataram',
        ':logo' => '',
        ':id' => '1'
    );
    $query->execute($data);
    echo "Data siswa telah diupdate";
}catch(PDOException $e){
    echo "Error! gagal mengedit data siswa:".$e->getMessage();
}

<?php
include '../../conf.php';
include '../../conn.php';
$id = post('id');
$nama = post('nama');
$alamat = post('alamat');
$update_logo = "";
if($_FILES['logo']['tmp_name']!=""){
$tmp_logo = $_FILES['logo']['tmp_name'];
$logo = $_FILES['logo']['name'];
move_uploaded_file($tmp_logo, "../../assets/foto/".$logo);
$update_logo = ",`logo`='".$logo."'";
}
$simpan = $koneksi->prepare("UPDATE sekolah SET
`nama`='".$nama."',
`alamat`='".$alamat."'
".$update_logo."
WHERE
`id` ='".$id."'");
$simpan->execute();
header("location:../../index.php?p=sekolah");
?>