<?php
// include autoloader
require_once 'dompdf/autoload.inc.php';
?>