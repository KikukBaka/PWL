<form method="post" action="add.php"  enctype="multipart/form-data">
<table class="table1">
<tr>
<td><label style="color:#3a87ad; font-size:18px;">Nama</label></td>
<td width="30"></td>
<td><input type="text" name="fname" placeholder="Nama" required /></td>
</tr>
<tr>
<td><label style="color:#3a87ad; font-size:18px;">Alamat</label></td>
<td width="30"></td>
<td><input type="text" name="mname" placeholder="Alamat" required /></td>
</tr>
<tr>
 
</table>

</div>
<div class="modal-footer">
<button class="btn" data-dismiss="modal" aria-hidden="true">Tutup</button>
<button type="submit" name="Submit" class="btn btn-primary">Add</button>
</div>
 
 
</form>

