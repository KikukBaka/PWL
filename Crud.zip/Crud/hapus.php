<?php
$host = "localhost";
$user = "root";
$password = "";
$database_name = "crud_pdo";
$pdo = new PDO("mysql:host=$host;dbname=$database_name", $user, $password, array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
));
try{
    $query = $pdo->prepare("delete from siswa  where id = :id");
    $query->execute(array(
        ':id' => '1'
    ));
    echo "Data siswa sudah dihapus";
}catch(PDOException $e){
    echo "Gagal menghapus data siswa:".$e->getMessage();
}

<?php
include '../../conf.php';
include '../../conn.php';
$id = get('id');
$hapus = $koneksi->prepare("DELETE FROM sekolah WHERE `id` =
'".$id."'");
$hapus->execute();
header("location:../../index.php?p=sekolah");
?>